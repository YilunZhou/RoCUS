import math, sys
from matplotlib import pyplot as plt
import numpy as np
from numpy import random

sys.path.append("ds_klampt/")
import learn_gamma_fn
from modulation_utils import *
import modulation_svm
# import rbf_2d_env_svm

import pickle

# 3D Plotting
from mpl_toolkits import mplot3d

epsilon = sys.float_info.epsilon

#######################
## Common Functions  ##
#######################
def rand_target_loc():
    '''
    generate random target location
    '''
    # ORIGINAL UNIFORM DISTRIBUTION
    # x = np_random.uniform(low=0.05, high=0.5)
    # if np_random.randint(0, 2) == 0:
    #     x = -x
    # y = np_random.uniform(low=-0.3, high=0.2)
    # z = np_random.uniform(low=0.65, high=1.0)

    # MODIFIED TO ACCOUNT FOR CHANGE IN REFERENCE FRAME
    y = np.random.uniform(low=0.05, high=0.5)
    if np.random.randint(0, 2) == 0:
        y = -y
    x = np.random.uniform(low = 0.3, high = 0.8)
    # z = np.random.uniform(low=0.65,  high = 1.0)
    z = np.random.uniform(low=0.65,  high = 0.95)

    return x, y, z


########################################################
##     Tests to run different modulation scenarios    ##
########################################################

def create_franka_dataset(dimension, grid_size, plot_training_data, with_wall = 0):
    grid_limits_x = [ 0.1, 1.0]
    grid_limits_y = [-0.8, 0.8]
    grid_limits_z = [0.55, 1.3]

    xx, yy, zz    = np.meshgrid(np.linspace(grid_limits_x[0], grid_limits_x[1], grid_size), np.linspace(grid_limits_y[0], grid_limits_y[1], grid_size), np.linspace(grid_limits_z[0], grid_limits_z[1], grid_size))
    X  = np.c_[xx.ravel(), yy.ravel(), zz.ravel()].T
    Y  = np.ones(X.shape[1]).T
    C  = np.zeros(X.shape[1]).T

    for i in range(X.shape[1]):
        # The table Top
        if (X[2,i] < 0.625):
            Y[i] = 0  
            C[i] = 1

    if with_wall:         
        for i in range(X.shape[1]):
            # Virtual wall to bound the workspace
            if (X[0,i] > 0.90):
                Y[i] = 0  
                C[i] = 1

    for i in range(X.shape[1]):            
        # The vertical wall
        if (X[0,i]>= 0.3):
          if (X[1,i]>=-0.03 and X[1,i]<=0.03): 
           if (X[2,i] >= 0.635 and X[2,i] <= 0.975):
             Y[i] = 0
             C[i] = 2        
    
    for i in range(X.shape[1]):            
        # The horizontal wall
        if (X[0,i]>= 0.3):
          if (X[1,i]>=-0.45 and X[1,i]<=0.45): 
              if (X[2,i] >= 0.965 and X[2,i] <= 1.085): 
                Y[i] = 0
                C[i] = 2                          
    Y = 1-Y
    if dimension==2:
        print("Getting a 2D Slice along the x-axis")
        x_slice_idx = (X[0,:] == 1.0)
        X_slice = X[:,x_slice_idx]
        Y_slice = Y[x_slice_idx]
        C_slice = C[x_slice_idx]
        X_FREE  = X_slice[:,C_slice.T == 0]
        X_OBS1  = X_slice[:,C_slice.T == 1]
        X_OBS2  = X_slice[:,C_slice.T == 2]
        if plot_training_data:
            plt.figure()
            plt.axis([grid_limits_y[0], grid_limits_y[1], grid_limits_z[0], grid_limits_z[1]])
            plt.plot(X_FREE[1,:], X_FREE[2,:],'.', color='#57B5E5', label='No Collision')
            plt.plot(X_OBS1[1,:], X_OBS1[2,:],'.', color='#833939', label='Obstacle 1')            
            plt.plot(X_OBS2[1,:], X_OBS2[2,:],'.', color='#833939', label='Obstacle 2')            
            plt.title('Franka ROCUS Collision Dataset',fontsize=15)
            plt.gca().set_aspect('equal', adjustable='box')
            plt.show()

        return X_slice[1:3,:], Y_slice, C_slice
    else: 
        
        X_FREE      = X[:,C.T == 0]
        X_OBS1      = X[:,C.T == 1]
        X_OBS2      = X[:,C.T == 2]
        if plot_training_data:
            print("Plotting 3D Data")
            fig = plt.figure()  
            ax = plt.axes(projection='3d')
            ax.scatter3D(X_FREE[0,:],X_FREE[1,:], X_FREE[2,:],'.', alpha= 0.1, color='#57B5E5', label='No Collision');
            ax.scatter3D(X_OBS1[0,:],X_OBS1[1,:], X_OBS1[2,:],'.', color='#833939', label='No Collision');
            ax.scatter3D(X_OBS2[0,:],X_OBS2[1,:], X_OBS2[2,:],'.', color='#833939', label='No Collision');
            ax.view_init(30, -40)
            ax.set_xlabel('$x_1$',fontsize=15)
            ax.set_ylabel('$x_2$',fontsize=15)
            ax.set_zlabel('$x_3$',fontsize=15)
            plt.title('Franka ROCUS Collision Dataset',fontsize=15)
            filename = "franka_environment_collision_dataset"
            plt.savefig(filename+".png", dpi=300)
            plt.savefig(filename+".pdf", dpi=300)

            plt.show()
        return X, Y, C

def create_franka_dataset_pyb_coord(grid_size=30, plot_training_data=False):
    lin_x = [-0.8, 0.8, grid_size]
    lin_y = [-0.5, 0.4, grid_size]
    lin_z = [0.55, 1.3, grid_size]

    xx, yy, zz = np.meshgrid(np.linspace(*lin_x), np.linspace(*lin_y), np.linspace(*lin_z))
    X  = np.c_[xx.ravel(), yy.ravel(), zz.ravel()].T  # 3 x N array with each column representing a data point
    Y  = np.ones(X.shape[1]).T
    C  = np.zeros(X.shape[1]).T
    # table top: z < 0.625
    # vertical: -0.03 <= x <= 0.03 and y >= -0.3 and 0.635 <= z <= 0.975
    # horizontal: -0.45 <= x <= 0.45 and y >= -0.3 and 0.965 <= z <= 1.085
    # virtual: y > 0.3
    for i in range(X.shape[1]):
        x, y, z = X[:, i]
        tabletop = (z < 0.625)
        vertical = (-0.03 <= x <= 0.03 and y >= -0.3 and 0.635 <= z <= 0.975)
        horizontal = (-0.45 <= x <= 0.45 and y >= -0.3 and 0.965 <= z <= 1.085)
        virtual = (y > 0.3)
        if tabletop or vertical or horizontal or virtual:
            Y[i] = 0
    Y = 1 - Y
    return X, Y, C

# # --- STATUS: WORKING! -- fix the gamma functions --- #
def test3D_HBS_svmlearnedGammas(x_target, x_initial, gamma_type):
    # Create 3D Dataset        
    grid_size      = 30
    X, Y, c_labels = create_franka_dataset(dimension=3, grid_size=grid_size, plot_training_data=0, with_wall=1)
    gamma_svm      = 20
    c_svm          = 20
    grid_limits_x  = [0.1, 1.0]
    grid_limits_y  = [-0.8, 0.8]
    grid_limits_z  = [0.55, 1.1]
    dt             = 0.03

    print('learning')
    # Learn Gamma Function!
    # Same SVM for all Gammas (i.e. normals will be the same)
    learned_obstacles = learn_gamma_fn.create_obstacles_from_data(data=X, label=Y, 
        plot_raw_data=False,  gamma_svm=gamma_svm, c_svm=c_svm, cluster_labels = c_labels)
    print(learned_obstacles)
    quit()

    # Save model!
    gamma_svm_model = (learned_obstacles, gamma_svm, c_svm)
    pickle.dump(gamma_svm_model, open("./ds_klampt/models/gammaSVM_frankaROCUS.pkl", 'wb'))
    print('done')

    # -- Draw Normal Vector Field of Gamma Functions and Modulated DS --- #
    grid_limits_x = [ 0.1, 1.0]
    grid_limits_y = [-0.8, 0.8]
    grid_limits_z = [0.55, 1.3]

    xx, yy, zz    = np.meshgrid(np.linspace(grid_limits_x[0], grid_limits_x[1], grid_size), np.linspace(grid_limits_y[0], grid_limits_y[1], grid_size), np.linspace(grid_limits_z[0], grid_limits_z[1], grid_size))
    positions  = np.c_[xx.ravel(), yy.ravel(), zz.ravel()].T

    # This will use the single gamma function formulation (which is not entirely correct due to handling of the reference points)
    classifier        = learned_obstacles['classifier']
    max_dist          = learned_obstacles['max_dist']
    reference_points  = learned_obstacles['reference_points']
    gamma_svm         = learned_obstacles['gamma_svm']
    n_obstacles       = learned_obstacles['n_obstacles']
    filename          = "./ds_klampt/figures/svmlearnedGamma_combined_3D"


    ########################################################################################
    # ------ Visualize Gammas and Vector Field! -- Make self-contained function ------ #
    fig1 = plt.figure()  
    ax1 = plt.axes(projection='3d')
    plt.title('HBS Modulated DS',fontsize=15)
    ax1.set_xlim3d(grid_limits_x[0], grid_limits_x[1])
    ax1.set_ylim3d(grid_limits_y[0], grid_limits_y[1])
    ax1.set_zlim3d(grid_limits_z[0], grid_limits_z[1])
    filename    = "./ds_klampt/figures/svmlearnedGamma_combined_modDS_3D"

    X_OBS   = X[:,Y == 1]
    # GAMMA_SCORE_OBS = gamma_score[Y == 1]
    ax1.scatter(X_OBS[0,::10],X_OBS[1,::10], X_OBS[2,::10], edgecolor="r", facecolor="gold");
    

    print('begin integrating')
    # Integrate trajectories from initial point
    repetitions  = 1
    for i in range(repetitions):
        x_target  = rand_target_loc()
        x = x_initial
        ax1.scatter(x[0], x[1], x[2], edgecolor="b", facecolor="blue")
        for j in range(100):
            orig_ds    = linear_controller(x_cur, x_target)
            _, x_dot = modulation_svm.forward_integrate_singleGamma_HBS(x, x_target, learned_obstacles, dt=1, eps=0.03, max_N = 1)
            # modulation_singleGamma_HBS_multiRef(x, orig_ds, gamma_query, normal_vec_query, obstacle_reference_points
            x_dot = x_dot[0]
            x_dot = x_dot / x_dot.max() * 0.01
            x += x_dot
            input('xdot')
            print(x_dot)
            ax1.scatter(x[0], x[1], x[2], edgecolor="b", facecolor="blue")
        print("Integrated Trajectory {} complete.".format(i))


    # print("reference_points", reference_points)
    reference_point = reference_points[0]
    # print("reference point 1: ", reference_point)
    ax1.scatter3D([reference_point[0]], [reference_point[1]], [reference_point[2]], edgecolor="r", facecolor="red")


    reference_point = reference_points[1]
    # print("reference point 2: ", reference_point)
    ax1.scatter3D([reference_point[0]], [reference_point[1]], [reference_point[2]], edgecolor="r", facecolor="red")


    ax1.view_init(30, -40)
    ax1.set_xlabel('$x_1$',fontsize=15)
    ax1.set_ylabel('$x_2$',fontsize=15)
    ax1.set_zlabel('$x_3$',fontsize=15)
    plt.savefig(filename+".png", dpi=300)
    plt.savefig(filename+".pdf", dpi=300)
    plt.show()
    print("DONE")



if __name__ == '__main__':
    gamma_type = 0
    # x_target = np.array([0.8, 0.2])
    # x_target  = np.array([0.20, 0.65, 0.625])
    x_target  = rand_target_loc()
    x_initial = np.array([0.516, -0.000, 1.221])
    test3D_HBS_svmlearnedGammas(x_target, x_initial, gamma_type)


