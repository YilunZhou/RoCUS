import math, sys
from matplotlib import pyplot as plt
import numpy as np
from sklearn.svm import SVR, SVC
from numpy import random as np_random

# sys.path.append("environment_generation/")
# from obstacles import GammaCircle2D, GammaRectangle2D, GammaCross2D
# import sample_environment

import learn_gamma_fn
from modulation_utils import *
# import rbf_2d_env_svm

epsilon = sys.float_info.epsilon

#######################
## Common Functions  ##
#######################
def null_space_bases(n):
    '''construct a set of d-1 basis vectors orthogonal to the given d-dim vector n'''
    d = len(n)
    es = []
    # Random vector
    x = np.random.rand(d)
    # Make it orthogonal to n
    x -= x.dot(n) * n / np.linalg.norm(n)**2
    # normalize it
    x /= np.linalg.norm(x)
    es.append(x)
    # print(np.dot(n,x))
    if np.dot(n,x) > 1e-10:
        raise AssertionError()

    # if 3d make cross product with x
    if d == 3:
        y = np.cross(x,n)
        es.append(y)
        # print(np.dot(n,y), np.dot(x,y))
        if np.dot(n,y) > 1e-10:
            raise AssertionError()
        if np.dot(x,y) > 1e-10:
            raise AssertionError()
    return es


def rand_target_loc(np_random):
    '''
    generate random target location
    '''
    x = np_random.uniform(low=0.05, high=0.5)
    if np_random.randint(0, 2) == 0:
        x = -x
    y = np_random.uniform(low=-0.3, high=0.2)
    z = np_random.uniform(low=0.65, high=1.0)
    return x, z


def linear_controller(x, x_target, max_norm=0.1):
    x_dot = x_target - x
    n = np.linalg.norm(x_dot)
    if n < max_norm:
        return x_dot
    else:
        return x_dot / n * max_norm

def behavior_length(x_traj):
    '''calculate the total length of the trajectory'''
    diffs = x_traj[1:] - x_traj[:-1]
    dists = np.linalg.norm(diffs, axis=1, ord=2)
    return dists.sum()

########################################################################################################################
## For use with the parametrized gamma functions (circles, rectangles, cross) as well as the RBF defined environments ##
########################################################################################################################


def forward_integrate_singleGamma_HBS(x_initial, x_target, learned_gamma, dt, eps, max_N):
    '''
    forward integration of the HBS modulation controller starting from x_initial,
    toward x_target, with obstacles given as a list of gamma functions.
    integration interval is dt, and N integration steps are performed.
    return an (N+1) x d tensor for x trajectory and an N x d tensor for x_dot trajectory.
    '''

    # Parse Gamma
    classifier        = learned_gamma['classifier']
    max_dist          = learned_gamma['max_dist']
    reference_points  = learned_gamma['reference_points']
    dim = len(x_target)
    # print(dim)
    x_traj = []
    x_traj.append(x_initial)
    x_dot_traj = []
    x_cur = x_initial
    # print("Before Integration")
    for i in range(max_N):
    #     print(x_cur)
    #     print(x_target)
        gamma_val  = learn_gamma_fn.get_gamma(x_cur, classifier, max_dist, reference_points, dimension=dim)
        # print(gamma_val)
        normal_vec = learn_gamma_fn.get_normal_direction(x_cur, classifier, reference_points, max_dist, dimension=dim)        
        # print(normal_vec)
        orig_ds    = linear_controller(x_cur, x_target)
        # print(orig_ds)
        x_dot      = modulation_singleGamma_HBS_multiRef(query_pt=x_cur, orig_ds=orig_ds, gamma_query=gamma_val,
                            normal_vec_query=normal_vec.reshape(dim), obstacle_reference_points=reference_points, repulsive_gammaMargin=0.01)
        x_dot      = x_dot/np.linalg.norm(x_dot + epsilon) * 0.03
        x_dot_traj.append(x_dot)
        x_cur = x_cur + x_dot * dt
        if np.linalg.norm(x_cur - x_target) < eps:
            print("Attractor Reached")
            break
        x_traj.append(x_cur)
    return np.stack(x_traj), np.stack(x_dot_traj)




def modulation_singleGamma_HBS_multiRef(query_pt, orig_ds, gamma_query, normal_vec_query, obstacle_reference_points, repulsive_gammaMargin = 0.01, sticky_surface = False):
    '''
        Computes modulated velocity for an environment described by a single gamma function
        and multiple reference points (describing multiple obstacles)
    '''

    # Add: Expand Boundary -- this doesn't work as I hoped
    # if gamma_query < 1.25 and gamma_query > 1.0:
    #     gamma_query = 1.0

    # Add: Contingencies for low gamma (inside obstacle) and high gamma (somewhere far away!)
    if gamma_query < 1.0:
        return np.zeros(orig_ds.shape)

    if gamma_query > 1e9:
        return orig_ds

    try:
        len(obstacle_reference_points.shape)
        reference_point = obstacle_reference_points
        # print("HEEEERE")
    except:
        reference_point = find_closest_reference_point(query_pt, obstacle_reference_points)

    # Add: Move away from center/reference point in case of a collision
    pos_relative     = -(query_pt - reference_point)
    if gamma_query < ( 1 + repulsive_gammaMargin):
        repulsive_power =  5
        repulsive_factor = 5
        repulsive_gamma = (1 + repulsive_gammaMargin)
        repulsive_speed =  ((repulsive_gamma/gamma_query)**repulsive_power-
                               repulsive_gamma)*repulsive_factor
        norm_xt = np.linalg.norm(pos_relative)
        if (norm_xt): # nonzero
            repulsive_velocity = pos_relative/np.linalg.norm(pos_relative) * repulsive_speed
        else:
            repulsive_velocity = np.zeros(dim)
            repulsive_velocity[0] = 1*repulsive_speed
        x_dot_mod = -repulsive_velocity
    else:
        # Calculate real modulated dynamical system
        M = modulation_singleGamma_HBS(x=query_pt, orig_ds = orig_ds, normal_vec=normal_vec_query, gamma_pt=gamma_query,
            reference_point=reference_point)
        x_dot_mod = np.matmul(M, orig_ds.reshape(-1, 1)).flatten()

    # Add: Sticky Surface
    if sticky_surface:
        xd_relative_norm = np.linalg.norm(orig_ds)
        if xd_relative_norm:
            # Limit maximum magnitude
            eigenvalue_magnitude = 1 - 1./abs(gamma_query)**1
            mag = np.linalg.norm(mod_ds)
            mod_ds = mod_ds/mag*xd_relative_norm * eigenvalue_magnitud

    return x_dot_mod


######################################################################################################################
## For use with non-class defined gamma functions (singleGamma is a single gamma function describing all obstacles) ##
######################################################################################################################
def modulation_singleGamma_HBS(x, orig_ds, normal_vec, gamma_pt, reference_point, ref_adapt = True, tangent_scale_max = 5):
    '''
        Compute modulation matrix for a single obstacle described with a gamma function
        and unique reference point
    '''
    x = np.array(x)
    assert len(x.shape) == 1, 'x is not 1-dimensional?'
    d = x.shape[0]
    n = normal_vec

    # Compute the Eigen Bases by adapting the reference direction!
    if ref_adapt:
        E, E_orth = compute_decomposition_matrix(x, normal_vec, reference_point)
    else:
        # Compute the Eigen Bases by NO adaptation of the reference direction!
        es = null_space_bases(n)
        r =  x - reference_point
        bases = [r] + es
        E = np.stack(bases).T
        E = E / np.linalg.norm(E, axis=0)

    # print("gamma", gamma_pt)
    # print("E", E)
    invE = np.linalg.inv(E)

    # Compute Diagonal Matrix
    tangent_scaling = 1
    if gamma_pt <=1:
        inv_gamma = 1
    else:
        inv_gamma       = 1 / gamma_pt
        # Consider TAIL EFFECT!
        tail_angle = np.dot(normal_vec, orig_ds)
        if (tail_angle) < 0:
            # print("Going TOWARDS obstacle!")
            tangent_scaling = max(1, tangent_scale_max - (1-inv_gamma))
            lambdas = np.stack([1 - inv_gamma] + [tangent_scaling*(1 + inv_gamma)] * (d-1))            
        else:
            # print("Going AWAY from obstacle!")
            tangent_scale_max = 1.0
            tangent_scaling   = 1.0
            lambdas = np.stack([1] + [tangent_scaling*(1 + inv_gamma)] * (d-1))



    D = np.diag(lambdas)
    # print("D", D)
    M = np.matmul(np.matmul(E, D), invE)

    if gamma_pt < 1.0:
        M =  np.zeros(M.shape)

    if gamma_pt > 1e9:
        M =  np.identity(d)

    return M
